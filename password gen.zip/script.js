// Character sets
const uppercaseChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const lowercaseChars = 'abcdefghijklmnopqrstuvwxyz';
const numberChars = '0123456789';
const symbolChars = '!@#$%^&*()_+~`|}{[]:;?><,./-=';

// Get DOM elements for index.html
const lengthEl = document.getElementById('length');
const uppercaseEl = document.getElementById('uppercase');
const lowercaseEl = document.getElementById('lowercase');
const numbersEl = document.getElementById('numbers');
const symbolsEl = document.getElementById('symbols');
const generateBtn = document.getElementById('generate');
const passwordEl = document.getElementById('password');
const copyBtn = document.getElementById('copy');
const modeEl = document.getElementById('mode');

// Get DOM elements for custom.html
const generateCustomBtn = document.getElementById('generateCustom');
const customTextEl = document.getElementById('customText');
const customPasswordEl = document.getElementById('customPassword');
const copyCustomBtn = document.getElementById('copyCustom');

// Function to determine additional characters based on mode (Removed in main generator)
function getModeAdditionalChars(mode) {
    switch(mode) {
        case 'easy':
            return ''; // No additional constraints
        case 'medium':
            return symbolChars;
        case 'hard':
            return uppercaseChars + numberChars + symbolChars;
        default:
            return '';
    }
}

// Event listener for generate button (index.html)
if (generateBtn) {
    generateBtn.addEventListener('click', () => {
        let length = parseInt(lengthEl.value);
        const includeUpper = uppercaseEl.checked;
        const includeLower = lowercaseEl.checked;
        const includeNumbers = numbersEl.checked;
        const includeSymbols = symbolsEl.checked;
        const mode = modeEl.value;

        // Validate input
        if (isNaN(length) || length < 4 || length > 20) {
            alert('Please enter a password length between 4 and 20.');
            return;
        }

        if (!includeUpper && !includeLower && !includeNumbers && !includeSymbols) {
            alert('Please select at least one character type.');
            return;
        }

        const password = generatePassword(length, includeUpper, includeLower, includeNumbers, includeSymbols);
        passwordEl.value = password;
    });
}

// Event listener for generate custom button (custom.html)
if (generateCustomBtn) {
    generateCustomBtn.addEventListener('click', () => {
        const customText = customTextEl.value.trim();
        const mode = modeEl.value;

        if (customText === '') {
            alert('Please enter some text to base your password on.');
            return;
        }

        const password = generateCustomPassword(customText, mode);
        customPasswordEl.value = password;
    });
}

// Function to generate password with selected criteria
function generatePassword(length, upper, lower, number, symbol) {
    let charSet = '';
    if (upper) charSet += uppercaseChars;
    if (lower) charSet += lowercaseChars;
    if (number) charSet += numberChars;
    if (symbol) charSet += symbolChars;

    let password = '';
    
    // Ensure at least one character from each selected type
    let mandatoryChars = [];
    if (upper) mandatoryChars.push(getRandomChar(uppercaseChars));
    if (lower) mandatoryChars.push(getRandomChar(lowercaseChars));
    if (number) mandatoryChars.push(getRandomChar(numberChars));
    if (symbol) mandatoryChars.push(getRandomChar(symbolChars));

    for (let i = 0; i < length; i++) {
        password += getRandomChar(charSet);
    }

    // Replace first few characters with mandatory characters to ensure inclusion
    password = password.split('');
    for (let i = 0; i < mandatoryChars.length && i < password.length; i++) {
        password[i] = mandatoryChars[i];
    }

    return password.join('');
}
const modeChars = getModeAdditionalChars(mode);
if (mode === 'medium') {
    charSet += modeChars;
} else if (mode === 'hard') {
    charSet += modeChars;
}
// Function to generate custom password based on input text and mode
function generateCustomPassword(text, mode) {
    let password = text;

    switch(mode) {
        case 'easy':
            // Append two-digit number
            password += getRandomNumber(10, 99);
            break;
        case 'medium':
            // Append two-digit number and a symbol
            password += getRandomNumber(10, 99) + getRandomChar(symbolChars);
            break;
        case 'hard':
            // Mix uppercase letters within the text, append number and symbol
            password = mixCase(text);
            password += getRandomNumber(10, 99) + getRandomChar(symbolChars);
            // Optionally shuffle to avoid predictable patterns
            password = shuffleString(password);
            break;
        default:
            password += getRandomNumber(10, 99);
    }

    return password;
}

// Helper function to get a random character from a string
function getRandomChar(characters) {
    return characters[Math.floor(Math.random() * characters.length)];
}

// Helper function to get a random number within a range
function getRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Helper function to mix uppercase and lowercase letters in a string
function mixCase(str) {
    let mixed = '';
    for (let char of str) {
        if (Math.random() > 0.5) {
            mixed += char.toUpperCase();
        } else {
            mixed += char.toLowerCase();
        }
    }
    return mixed;
}

// Helper function to shuffle a string (Fisher-Yates Shuffle)
function shuffleString(str) {
    const arr = str.split('');
    for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr.join('');
}

// Event listener for copy button (index.html)
if (copyBtn) {
    copyBtn.addEventListener('click', () => {
        const password = passwordEl.value;
        if (!password) {
            alert('Nothing to copy!');
            return;
        }
        navigator.clipboard.writeText(password)
            .then(() => {
                alert('Password copied to clipboard!');
            })
            .catch(err => {
                alert('Failed to copy password.');
                console.error('Error copying to clipboard:', err);
            });
    });
}

// Event listener for copy custom button (custom.html)
if (copyCustomBtn) {
    copyCustomBtn.addEventListener('click', () => {
        const password = customPasswordEl.value;
        if (!password) {
            alert('Nothing to copy!');
            return;
        }
        navigator.clipboard.writeText(password)
            .then(() => {
                alert('Password copied to clipboard!');
            })
            .catch(err => {
                alert('Failed to copy password.');
                console.error('Error copying to clipboard:', err);
            });
    });
}
function generatePassword() {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()';
    let password = '';
    for (let i = 0; i < 12; i++) {
        password += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    document.getElementById('password').value = password;
}

// Copy to Clipboard with Privacy
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert("Password copied to clipboard. It will be cleared in 10 seconds.");
        setTimeout(() => navigator.clipboard.writeText(""), 10000); // Clears clipboard after 10 seconds
    }).catch(err => console.error("Error copying to clipboard: ", err));
}

// Event Listeners
document.getElementById('generateBtn').addEventListener('click', generatePassword);
document.getElementById('copyBtn').addEventListener('click', () => {
    const password = document.getElementById('password').value;
    if (password) copyToClipboard(password);
});